#include "ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3.h"
#include "ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61.h"

typedef union ffx_fsr2_tcr_autogen_pass_16bit_PermutationKey {
    struct {
        uint32_t FFX_FSR2_OPTION_REPROJECT_USE_LANCZOS_TYPE : 1;
        uint32_t FFX_FSR2_OPTION_HDR_COLOR_INPUT : 1;
        uint32_t FFX_FSR2_OPTION_LOW_RESOLUTION_MOTION_VECTORS : 1;
        uint32_t FFX_FSR2_OPTION_JITTERED_MOTION_VECTORS : 1;
        uint32_t FFX_FSR2_OPTION_INVERTED_DEPTH : 1;
        uint32_t FFX_FSR2_OPTION_APPLY_SHARPENING : 1;
    };
    uint32_t index;
} ffx_fsr2_tcr_autogen_pass_16bit_PermutationKey;

typedef struct ffx_fsr2_tcr_autogen_pass_16bit_PermutationInfo {
    const uint32_t       blobSize;
    const unsigned char* blobData;


    const uint32_t  numCBVResources;
    const char**    cbvResourceNames;
    const uint32_t* cbvResourceBindings;
    const uint32_t* cbvResourceCounts;
    const uint32_t* cbvResourceSpaces;

    const uint32_t  numSRVResources;
    const char**    srvResourceNames;
    const uint32_t* srvResourceBindings;
    const uint32_t* srvResourceCounts;
    const uint32_t* srvResourceSpaces;

    const uint32_t  numUAVResources;
    const char**    uavResourceNames;
    const uint32_t* uavResourceBindings;
    const uint32_t* uavResourceCounts;
    const uint32_t* uavResourceSpaces;

    const uint32_t  numSamplerResources;
    const char**    samplerResourceNames;
    const uint32_t* samplerResourceBindings;
    const uint32_t* samplerResourceCounts;
    const uint32_t* samplerResourceSpaces;

    const uint32_t  numRTAccelerationStructureResources;
    const char**    rtAccelerationStructureResourceNames;
    const uint32_t* rtAccelerationStructureResourceBindings;
    const uint32_t* rtAccelerationStructureResourceCounts;
    const uint32_t* rtAccelerationStructureResourceSpaces;
} ffx_fsr2_tcr_autogen_pass_16bit_PermutationInfo;

static const uint32_t g_ffx_fsr2_tcr_autogen_pass_16bit_IndirectionTable[] = {
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
};

static const ffx_fsr2_tcr_autogen_pass_16bit_PermutationInfo g_ffx_fsr2_tcr_autogen_pass_16bit_PermutationInfo[] = {
    { g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_size, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_data, 2, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_CBVResourceNames, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_CBVResourceBindings, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_CBVResourceCounts, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_CBVResourceSpaces, 7, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_SRVResourceNames, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_SRVResourceBindings, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_SRVResourceCounts, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_SRVResourceSpaces, 4, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_UAVResourceNames, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_UAVResourceBindings, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_UAVResourceCounts, g_ffx_fsr2_tcr_autogen_pass_16bit_0dbf3244ab35f740e7a3b448d9b769b3_UAVResourceSpaces, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_size, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_data, 2, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_CBVResourceNames, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_CBVResourceBindings, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_CBVResourceCounts, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_CBVResourceSpaces, 7, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_SRVResourceNames, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_SRVResourceBindings, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_SRVResourceCounts, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_SRVResourceSpaces, 4, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_UAVResourceNames, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_UAVResourceBindings, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_UAVResourceCounts, g_ffx_fsr2_tcr_autogen_pass_16bit_e34c17d17925b6532639a6ff27084a61_UAVResourceSpaces, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
};

